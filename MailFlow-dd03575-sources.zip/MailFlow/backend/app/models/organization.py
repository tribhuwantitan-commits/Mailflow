"""Organization and membership models."""

from __future__ import annotations

from datetime import datetime
from uuid import UUID, uuid4

from sqlalchemy import (
    JSON,
    CheckConstraint,
    DateTime,
    ForeignKey,
    Index,
    String,
    Uuid,
    func,
    text,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base
from app.models.identity import User


class Organization(Base):
    """A customer tenant with one explicit owner and member rows."""

    __tablename__ = "organizations"
    __table_args__ = (Index("ix_organizations_owner_user_id", "owner_user_id"),)

    id: Mapped[UUID] = mapped_column(Uuid(as_uuid=True), primary_key=True, default=uuid4)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    owner_user_id: Mapped[UUID] = mapped_column(
        Uuid(as_uuid=True), ForeignKey("users.id", ondelete="RESTRICT"), nullable=False
    )
    # Which sending_plans row applies. Defaults to the free tier so a newly created
    # tenant is capped immediately rather than unlimited until someone notices.
    plan: Mapped[str] = mapped_column(
        String(40),
        ForeignKey("sending_plans.slug", ondelete="RESTRICT"),
        nullable=False,
        server_default="free",
        default="free",
    )
    # Support-issued lifts for a single tenant, kept separate from the plan so the
    # catalogue stays a catalogue. NULL means "use the plan value".
    plan_overrides: Mapped[dict | None] = mapped_column(
        JSON().with_variant(JSONB(), "postgresql"), nullable=True
    )
    # Proof that the contact address belongs to the signup. Card verification is the
    # other route in the plan ladder; both are recorded so a 100/day free tier can be
    # granted without a human looking at it.
    email_verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    card_verified_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    # Set by the reputation guard when a tenant's bounce/complaint rate crosses the
    # threshold; sending is refused until support clears it.
    sending_paused_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    sending_paused_reason: Mapped[str | None] = mapped_column(String(200))
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    owner: Mapped[User] = relationship(foreign_keys=[owner_user_id], viewonly=True)
    memberships: Mapped[list[OrganizationMembership]] = relationship(
        back_populates="organization",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )


class OrganizationMembership(Base):
    """User access to an organization; newly created organizations have an owner row."""

    __tablename__ = "organization_memberships"
    __table_args__ = (
        CheckConstraint("role IN ('owner', 'member')", name="ck_organization_memberships_role"),
        Index("ix_organization_memberships_user_id", "user_id"),
        Index(
            "uq_organization_memberships_single_owner",
            "organization_id",
            unique=True,
            postgresql_where=text("role = 'owner'"),
            sqlite_where=text("role = 'owner'"),
        ),
    )

    organization_id: Mapped[UUID] = mapped_column(
        Uuid(as_uuid=True),
        ForeignKey("organizations.id", ondelete="CASCADE"),
        primary_key=True,
    )
    user_id: Mapped[UUID] = mapped_column(
        Uuid(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        primary_key=True,
    )
    role: Mapped[str] = mapped_column(
        String(20), nullable=False, default="member", server_default="member"
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default=func.now()
    )

    organization: Mapped[Organization] = relationship(back_populates="memberships")
    user: Mapped[User] = relationship(back_populates="memberships")
