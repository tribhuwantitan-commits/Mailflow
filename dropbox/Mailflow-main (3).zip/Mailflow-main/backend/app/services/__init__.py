"""Application-level transaction helpers."""
